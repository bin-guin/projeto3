var ctx = document.getElementById("graficoLinha");
var graficoLinha = new Chart(ctx, {
    type: 'line',
    data: {
        labels: ["Jan/2023", "Fev/2023", "Mar/2023", "Abr/2023", "Mai/2023", "Jun/2023"],
        datasets: [{
            data: [22000, 25000, 18000, 34000, 56000, 64000],
            borderWidth: 5,
            borderColor: 'rgba(255, 0, 0)',
        }]
    },
    options: {
        legend: {
            display: false
        },
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true,
                    stepSize: 5000,
                    max: 65000,
                }
            }]
        }
    }
});
